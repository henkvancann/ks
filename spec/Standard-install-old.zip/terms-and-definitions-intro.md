# Terms and Definitions Intro

## Demo terms, definitions and external definitions

A demo of terms and definitions, and references to external definitions.
