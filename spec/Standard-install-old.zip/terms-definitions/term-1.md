[[def: term 1, term one, Term One]]

~ Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum faucibus volutpat justo, sed ornare velit.

~ Refs examples: [[ref: Term 2]], [[ref: Term Two]], [[ref: Term 3]].

~ Xref example: [[xref: test-1, Aal]]

~ This Xref example does not work: [[xref: does-not-exist, Foo]]

~ Donec aliquam et ligula id congue. Sed eu urna et tellus placerat viverra. Quisque ut posuere magna, nec accumsan augue. Nullam mauris tortor, semper finibus elementum maximus, imperdiet in felis. Suspendisse quis imperdiet nibh, eget ultrices justo. Pellentesque vitae malesuada justo. Vestibulum quis scelerisque lectus, non rutrum odio. Aenean leo orci, semper non massa sed, facilisis ornare ipsum. Morbi at sem orci. Integer eros mi, faucibus sed lorem id, pharetra imperdiet nisl. Integer viverra enim vel luctus lobortis. Ut turpis tellus, consequat nec lectus et, dictum elementum nunc. Integer rhoncus venenatis molestie. Donec egestas condimentum ligula in porttitor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.

~ Extra text for testing purposes.
