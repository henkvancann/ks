[[def: term 4, term four, Term Four]]

~ Sed lorem nunc, ultricies nec nibh eu, bibendum sollicitudin arcu. Nullam porttitor condimentum elit ac commodo. Aenean ac augue quis arcu congue aliquam vitae in massa. Aliquam erat volutpat. Curabitur lobortis, sapien vitae mattis dignissim, risus augue iaculis risus, sed tempus sapien ex nec massa. Integer quis maximus nunc. Nunc ultrices sapien erat, at congue augue mattis sit amet. Aliquam condimentum luctus nunc, ut euismod augue commodo in.
